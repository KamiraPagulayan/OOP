import ClassPack.ClassAbstraction.*;
public class Abstraction {
    public static void main(String[] args) {
        Cat myCat = new Cat();
        myCat.sound();

        Dog myDog = new Dog();
        myDog.sound();
    }
}
