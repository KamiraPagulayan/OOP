package ClassPack.ClassInheritance;

public class Bird extends Animal{
    public int wings = 2;
}
