package ClassPack.ClassInheritance;

public class Cat extends Animal{
    public int legs = 4;
}
