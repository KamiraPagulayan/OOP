package ClassPack.ClassAbstraction;

public abstract class Animal {
    String name;
    int age;

    public abstract void sound();
}
