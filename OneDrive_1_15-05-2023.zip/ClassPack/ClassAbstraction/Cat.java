package ClassPack.ClassAbstraction;

public  class Cat extends Animal{

    public void sound(){
        System.out.println("mweow mweow");
    }
}
