package ClassPack.ClassPolymorphism;

public class Animal {
    int age;
    String name;

    public void eat(){
        System.out.print("nom nom");
    }

    
}
