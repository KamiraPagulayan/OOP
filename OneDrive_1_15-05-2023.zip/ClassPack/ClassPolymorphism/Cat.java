package ClassPack.ClassPolymorphism;

public class Cat extends Animal{
    //overriding
    public void eat(){
        System.out.print("skrt skrt");
    }
}
