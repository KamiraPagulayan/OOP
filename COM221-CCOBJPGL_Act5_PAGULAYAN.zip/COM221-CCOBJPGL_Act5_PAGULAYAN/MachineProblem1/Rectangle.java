package MachineProblem1;

public class Rectangle {
    
    private static double length;
    private static double width;

    public Rectangle(double length, double width){
        this.length = length;
        this.width = width;
    }

    public static double getLength(){
        return length;
    }

    public static double getWidth(){
        return width;
    }

    public void setLength(double length){
        this.length = length;
    }

    public void setWidth(double width){
        this.width = width;
    }

    public static double getArea(){
        return length*width;
    }
}
