package MachineProblem1;

public class Box extends Rectangle {
    public Box(double length, double width) {
        super(length, width);
    }

    private static double height;

    public void setBox(double height, double length, double width){
        this.height = height;
    }

    public double getHeight(){
        return height;
    }

    public void setHeight(double height){
        this.height = height;
    }

    public static double getVolume(){
        return getArea()*height;
    }   
}
