package MachineProblem1;
import java.util.Scanner;

public class Main {
   
    public static void main(String[]args){

        Rectangle myRectangle = new Rectangle(0, 0);
        Box myBox = new Box(0, 0);

        Scanner sc = new Scanner(System.in);

        System.out.print("Length: ");
        double length = sc.nextDouble();
        System.out.print("Width: ");
        double width = sc.nextDouble();
        System.out.print("Height: ");
        double height = sc.nextDouble();

        myRectangle.setLength(length);
        myRectangle.setWidth(width);
        myBox.setLength(length);
        myBox.setWidth(width);
        myBox.setHeight(height);

        
        System.out.println("The area of Rectangle is " + myRectangle.getArea());
        System.out.println("The volume of Box is " + myBox.getVolume());
    }
}
