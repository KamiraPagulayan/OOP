package MachineProblem2;

public class Rectangle extends Shape {
    
    public double getArea(double height, double width){
        return height*width;
    }
}

