package MachineProblem2;

public class Triangle extends Shape{
    
    public double getArea(double height, double width){
        return height*width/2;
    }
}
