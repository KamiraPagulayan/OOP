package MachineProblem2;
import java.util.Scanner;

public class Main {
   
    public static void main(String[]args){

        Shape myShape = new Shape();
        Rectangle myRectangle = new Rectangle();
        Triangle myTriangle = new Triangle();

        Scanner sc = new Scanner(System.in);

        System.out.print("Height: ");
        double height = sc.nextDouble();
        System.out.print("Width: ");
        double width = sc.nextDouble();

        myShape.setHeight(height);
        myShape.setWidth(width);

        System.out.println("Select a shape to compute: ");
        System.out.println("1.Rectangle\n2.Triangle");

        int choice = sc.nextInt();

        switch(choice) {
            case 1:
                System.out.print(myRectangle.getArea(height, width));
                break;
            case 2:
                System.out.print(myTriangle.getArea(height, width));
            default:
                break;
        }
    }
}
