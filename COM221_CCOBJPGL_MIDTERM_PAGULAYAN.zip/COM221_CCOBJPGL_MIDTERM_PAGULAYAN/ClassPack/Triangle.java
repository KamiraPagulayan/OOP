package ClassPack;

public class Triangle extends Shape {
    
    public Triangle(double base, double height) {
        super(base, height);
    }

    public double getArea() {
        return 0.5 * getParam1() * getParam2();
    }

    public double getVolume() {
        return getParam1() * getParam2();
    }
}
