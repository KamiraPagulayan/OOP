package ClassPack;

public class Circle extends Shape {
    
    public Circle(double radius) {
        super(radius);
    }
    //Circle does not have a volume
    public double getArea() {
        return Math.PI * getParam1() * getParam1();
    }
}