package ClassPack;

public class Square extends Shape {
    
    public Square(double side) {
        super(side);
    }

    public double getArea() {
        return Math.pow(getParam1(), 2);
    }

    public double getVolume() {
        return Math.pow(getParam1(), 3);
    }
}
