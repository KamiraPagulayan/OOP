import java.util.Scanner;

import ClassPack.Circle;
import ClassPack.Rectangle;
import ClassPack.Square;
import ClassPack.Triangle;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Choose a Shape to compute:");
        System.out.println("(1) Rectangle");
        System.out.println("(2) Square");
        System.out.println("(3) Triangle");
        System.out.println("(4) Circle");
        System.out.print("Select: ");

        int choose = sc.nextInt();

        switch (choose) {
            case 1:
                System.out.print("Enter the length of the Rectangle: ");
                double length = sc.nextDouble();
                System.out.print("Enter the width of the Rectangle: ");
                double width = sc.nextDouble();
                System.out.print("Enter the height of the Rectangle: ");
                double height = sc.nextDouble();

                Rectangle myRectangle = new Rectangle(length, width, height);
                System.out.println("Area: " + myRectangle.getArea());
                System.out.println("Volume: " + myRectangle.getVolume());
                break;
                
            case 2:
                System.out.print("Enter the length of the Side of the Square: ");
                double side = sc.nextDouble();

                Square mySquare = new Square(side);
                System.out.println("Area: " + mySquare.getArea());
                System.out.println("Volume: " + mySquare.getVolume());
                break;

            case 3:
                System.out.print("Enter the base of the Triangle: ");
                double base = sc.nextDouble();
                System.out.print("Enter the height of the Triangle: ");
                double heightTriangle = sc.nextDouble();

                Triangle myTriangle = new Triangle(base, heightTriangle);
                System.out.println("Area: " + myTriangle.getArea());
                System.out.println("Volume: " + myTriangle.getVolume());
                break;

            case 4:
                System.out.print("Enter the radius of the Circle: ");
                double radius = sc.nextDouble();

                Circle myCircle = new Circle(radius);
                System.out.println("Area: " + myCircle.getArea());
                break;
            default:
                break;
        }
    }
}
